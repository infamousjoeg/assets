# Conjur.CreateHost

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**annotations** | **[String]** |  | 
**apiKey** | **String** |  | 
**createdAt** | **String** |  | 
**id** | **String** |  | 
**owner** | **String** |  | 
**permissions** | **[String]** |  | 


