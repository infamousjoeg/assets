# Conjur.CsrBody

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**csr** | **String** |  | 
**ttl** | **String** |  | 


