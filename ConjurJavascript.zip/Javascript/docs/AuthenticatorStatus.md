# Conjur.AuthenticatorStatus

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** | The error message if there was an error | [optional] 
**status** | **String** | The status of the endpoint, &#39;error&#39; if there was an error | 


