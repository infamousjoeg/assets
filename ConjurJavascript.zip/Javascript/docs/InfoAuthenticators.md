# Conjur.InfoAuthenticators

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**configured** | **[String]** |  | [optional] 
**enabled** | **[String]** |  | [optional] 
**installed** | **[String]** |  | [optional] 


