# Conjur.ResourcePermissions

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**policy** | **String** |  | [optional] 
**privilege** | **String** |  | [optional] 
**role** | **String** |  | [optional] 


