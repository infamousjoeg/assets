# Conjur.CreateHostForm

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**annotations** | [**Object**](.md) | Annotations to apply to the new host | [optional] 
**id** | **String** | Identifier of the host to be created. It will be created within the account of the host factory. | 


