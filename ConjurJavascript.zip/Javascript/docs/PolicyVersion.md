# Conjur.PolicyVersion

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clientIp** | **String** |  | [optional] 
**createdAt** | **String** |  | [optional] 
**finishedAt** | **String** |  | [optional] 
**id** | **String** |  | [optional] 
**policySha256** | **String** |  | [optional] 
**policyText** | **String** |  | [optional] 
**role** | **String** |  | [optional] 
**version** | **Number** |  | [optional] 


