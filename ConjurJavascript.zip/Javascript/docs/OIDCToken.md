# Conjur.OIDCToken

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idToken** | **String** |  | [optional] 


