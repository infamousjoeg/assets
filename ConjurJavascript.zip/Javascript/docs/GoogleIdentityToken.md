# Conjur.GoogleIdentityToken

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jwt** | **String** |  | [optional] 


