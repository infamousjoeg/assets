# Conjur.JWTToken

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jwt** | **String** |  | [optional] 


