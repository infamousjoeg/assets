# Conjur.Info

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authenticators** | [**InfoAuthenticators**](InfoAuthenticators.md) |  | [optional] 
**configuration** | [**Object**](.md) |  | [optional] 
**container** | **String** |  | [optional] 
**release** | **String** |  | [optional] 
**role** | **String** |  | [optional] 
**services** | [**Object**](.md) |  | [optional] 
**version** | **String** |  | [optional] 


