# Conjur.ResourceSecrets

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**expiresAt** | **String** |  | [optional] 
**version** | **Number** |  | [optional] 


