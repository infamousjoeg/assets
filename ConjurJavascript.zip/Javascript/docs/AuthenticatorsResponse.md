# Conjur.AuthenticatorsResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**configured** | **[String]** | The authenticators configured on the Conjur server | [optional] 
**enabled** | **[String]** | The authenticators enabled on the Conjur server | [optional] 
**installed** | **[String]** | The authenticators installed on the Conjur server | [optional] 


