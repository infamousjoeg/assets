# Conjur.LoadedPolicy

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**createdRoles** | [**Object**](.md) |  | [optional] 
**version** | **Number** |  | [optional] 


