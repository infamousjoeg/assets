# Conjur.ServiceAuthenticators

## Enum


* `iam` (value: `"authn-iam"`)

* `oidc` (value: `"authn-oidc"`)

* `ldap` (value: `"authn-ldap"`)

* `k8s` (value: `"authn-k8s"`)

* `gcp` (value: `"authn-gcp"`)

* `azure` (value: `"authn-azure"`)

* `jwt` (value: `"authn-jwt"`)


