# Conjur.CertificateJson

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**certificate** | **String** |  | [optional] 


