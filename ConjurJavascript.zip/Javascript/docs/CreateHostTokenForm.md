# Conjur.CreateHostTokenForm

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cidr** | **[String]** | Number of host tokens to create | [optional] 
**count** | **Number** | Number of host tokens to create | [optional] 
**expiration** | **String** | &#x60;ISO 8601 datetime&#x60; denoting a requested expiration time. | 
**hostFactory** | **String** | Fully qualified host factory ID | 


