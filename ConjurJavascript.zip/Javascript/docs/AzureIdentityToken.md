# Conjur.AzureIdentityToken

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jwt** | **String** |  | [optional] 


